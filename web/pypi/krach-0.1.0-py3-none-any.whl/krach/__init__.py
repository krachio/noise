import atexit
import os
import subprocess
import tempfile
import time
from pathlib import Path

from krach._mixer import VoiceMixer


def _repo_root() -> Path:
    return Path(__file__).parent.parent.parent.parent


def _wait_for_socket(path: Path, timeout: float = 5.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if path.exists():
            return True
        time.sleep(0.1)
    return False


def connect(bpm: float = 120, master: float = 0.7, build: bool = True) -> VoiceMixer:
    """Start krach-engine and return a connected VoiceMixer.

    ``bpm``: initial tempo.
    ``master``: master output gain (0.0-1.0).
    ``build``: if True, build krach-engine before starting.
    """
    from krach.patterns import Session
    from krach._copilot import parse_dsp_controls

    repo = _repo_root()
    engine_bin = repo / "target" / "debug" / "krach-engine"

    if build:
        print("building krach-engine...")
        subprocess.run(
            ["cargo", "build", "--bin", "krach-engine", "-q"],
            cwd=repo,
            check=True,
        )

    engine_sock = Path(tempfile.gettempdir()) / "krach-engine.sock"
    dsp_dir = Path.home() / ".krach" / "dsp"
    dsp_dir.mkdir(parents=True, exist_ok=True)

    engine_sock.unlink(missing_ok=True)
    env = {**os.environ, "RUST_LOG": os.environ.get("RUST_LOG", "info")}

    log_path = Path.home() / ".krach" / "engine.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    _log_file = log_path.open("w")

    engine_proc = subprocess.Popen(
        [str(engine_bin)],
        env={
            **env,
            "NOISE_SOCKET": str(engine_sock),
            "NOISE_DSP_DIR": str(dsp_dir),
        },
        stderr=_log_file,
    )

    def _cleanup() -> None:
        engine_proc.terminate()
        try:
            engine_proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            engine_proc.kill()
            engine_proc.wait()
        engine_sock.unlink(missing_ok=True)
        _log_file.close()

    atexit.register(_cleanup)

    if not _wait_for_socket(engine_sock):
        raise RuntimeError("krach-engine socket not ready after 5s")

    mm = Session(socket_path=str(engine_sock))
    mm.connect()

    # Pre-populate controls from DSP files already on disk (previous sessions).
    node_controls: dict[str, tuple[str, ...]] = {}
    for _p in dsp_dir.rglob("*.dsp"):
        controls = parse_dsp_controls(_p.read_text())
        if controls:
            _rel = _p.relative_to(dsp_dir).with_suffix("")
            node_controls[f"faust:{_rel}"] = controls

    kr = VoiceMixer(session=mm, dsp_dir=dsp_dir, node_controls=node_controls)
    kr.tempo = bpm
    kr.master = master

    # Ensure _mininotation is imported (attaches VoiceMixer.p at import time).
    import krach._mininotation  # type: ignore[reportUnusedImport]  # attaches VoiceMixer.p

    # Wait for engine to finish loading DSP files (hot-reload at startup).
    deadline = time.monotonic() + 10.0
    while time.monotonic() < deadline:
        try:
            mm.list_nodes()
            break
        except (TimeoutError, ConnectionError):
            time.sleep(0.1)
    else:
        raise RuntimeError("krach-engine not ready after 10s")

    return kr


def main() -> None:
    import anthropic

    from krach._copilot import SessionState, ask_claude, build_context, extract_code, format_status, split_cells
    from krach._pitch import NOTES as _NOTES
    import krach.dsp as krs

    kr = connect()

    _user_ns_keys: tuple[str, ...] = ()  # populated after user_ns is built

    def _session_state() -> SessionState:
        return SessionState(
            bpm=kr.tempo,
            playing=tuple(k for k, v in kr.slots.items() if v.playing),
            stopped=tuple(k for k, v in kr.slots.items() if not v.playing),
            nodes=tuple(kr.node_controls.keys()),
            node_controls=tuple(kr.node_controls.items()),
            in_scope=_user_ns_keys,
            active_voices=tuple(
                (name, v.type_id, v.gain, v.controls) for name, v in kr.voice_data.items()
            ),
        )

    def status() -> None:
        """Print current session state: BPM, slots, loaded nodes."""
        print(format_status(_session_state()))

    _cell_queue: list[str] = []

    def _paste(cell: str) -> None:
        import IPython
        print(cell)
        IPython.get_ipython().set_next_input(cell)  # type: ignore[union-attr]

    def c(prompt: str) -> None:
        """Ask Claude for help; splits response into cells, pastes the first."""
        model = os.environ.get("KRACH_MODEL", "claude-sonnet-4-6")
        client = anthropic.Anthropic()
        system = build_context(_session_state())
        response = ask_claude(client, model, system, prompt)
        code = extract_code(response)
        if not code:
            print(response)
            return
        cells = split_cells(code)
        _cell_queue.clear()
        _cell_queue.extend(cells[1:])
        _paste(cells[0])
        if _cell_queue:
            print(f"\n  ({len(_cell_queue)} more cell(s) — call cn() to advance)")

    def cn() -> None:
        """Paste the next queued cell (from the last c() call)."""
        if not _cell_queue:
            print("cell queue empty")
            return
        _paste(_cell_queue.pop(0))
        if _cell_queue:
            print(f"\n  ({len(_cell_queue)} more cell(s) — call cn() to advance)")

    # Bind session helpers onto kr instance
    kr.status = status  # type: ignore[attr-defined]
    kr.c = c  # type: ignore[attr-defined]
    kr.cn = cn  # type: ignore[attr-defined]

    print()
    print("  \u2588\u2588\u2557  \u2588\u2588\u2557\u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2557  \u2588\u2588\u2588\u2588\u2588\u2588\u2557\u2588\u2588\u2557  \u2588\u2588\u2557")
    print("  \u2588\u2588\u2551 \u2588\u2588\u2554\u255d\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2554\u2550\u2550\u2550\u2550\u255d\u2588\u2588\u2551  \u2588\u2588\u2551")
    print("  \u2588\u2588\u2588\u2588\u2588\u2554\u255d \u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255d\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2551\u2588\u2588\u2551     \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2551")
    print("  \u2588\u2588\u2554\u2550\u2588\u2588\u2557 \u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2551\u2588\u2588\u2551     \u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2551")
    print("  \u2588\u2588\u2551  \u2588\u2588\u2557\u2588\u2588\u2551  \u2588\u2588\u2551\u2588\u2588\u2551  \u2588\u2588\u2551\u255a\u2588\u2588\u2588\u2588\u2588\u2588\u2557\u2588\u2588\u2551  \u2588\u2588\u2551")
    print("  \u255a\u2550\u255d  \u255a\u2550\u255d\u255a\u2550\u255d  \u255a\u2550\u255d\u255a\u2550\u255d  \u255a\u2550\u255d \u255a\u2550\u2550\u2550\u2550\u2550\u255d\u255a\u2550\u255d  \u255a\u2550\u255d")
    print()
    print(f"  kr    VoiceMixer — kr.voice(), kr.play(), kr.note(), kr.hit(), ...")
    print(f"  krs   krach.dsp  — krs.Signal, krs.control(), krs.saw(), krs.lowpass(), ...")
    print()

    import IPython

    user_ns: dict[str, object] = {
        "kr": kr,
        "krs": krs,
        # Note constants for convenience (C0..B8)
        **_NOTES,
        # Compat aliases (will be removed in future)
        "status": status,
        "c": c,
        "cn": cn,
    }
    _user_ns_keys = tuple(sorted(user_ns))

    IPython.embed(  # type: ignore[reportUnknownMemberType]
        user_ns=user_ns,
        banner1="",
        banner2="",
    )

    kr.disconnect()
