"""Mini-notation parser — TidalCycles-inspired pattern strings."""

from __future__ import annotations

from krach.patterns.pattern import Pattern, rest

from krach._mixer import VoiceMixer, hit, note


def p(notation: str, **kwargs: float) -> Pattern:
    """Parse mini-notation string into a Pattern.

    Syntax:
        p("x . x . x . . x")       # x=hit(), .=rest()
        p("C4 E4 G4 ~ C5")         # note names, ~=rest
        p("[C4 E4] G4 B4")         # []=simultaneous (Stack via |)
        p("C4*2 E4 G4")            # *N=repeat
        p("C4 E4", vel=0.5)        # kwargs passed to note()
    """
    tokens = _tokenize(notation)
    atoms = [_parse_token(t, **kwargs) for t in tokens]
    if not atoms:
        raise ValueError("empty pattern")
    if len(atoms) == 1:
        return atoms[0]
    result = atoms[0]
    for a in atoms[1:]:
        result = result + a
    return result


def _tokenize(s: str) -> list[str | list[str]]:
    """Split into tokens. [...] becomes a nested list."""
    tokens: list[str | list[str]] = []
    i = 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            i += 1
        elif c == "[":
            j = s.index("]", i)
            inner = s[i + 1 : j].split()
            tokens.append(inner)
            i = j + 1
        else:
            j = i
            while j < len(s) and not s[j].isspace() and s[j] != "[":
                j += 1
            tokens.append(s[i:j])
            i = j
    return tokens


def _parse_token(token: str | list[str], **kwargs: float) -> Pattern:
    """Convert a token to a Pattern."""
    if isinstance(token, list):
        parts = [_parse_token(t, **kwargs) for t in token]
        result = parts[0]
        for part in parts[1:]:
            result = result | part
        return result

    # *N repeat suffix
    if "*" in token:
        base, count_str = token.rsplit("*", 1)
        count = int(count_str)
        return _parse_token(base, **kwargs) * count

    # Rest tokens
    if token in (".", "~", "-"):
        return rest()

    # Hit trigger
    if token in ("x", "X"):
        return hit("gate", **kwargs)

    # Note name
    return note(token, **kwargs)


# Attach p() onto VoiceMixer (deferred to avoid circular import at _mixer level).
VoiceMixer.p = staticmethod(p)  # type: ignore[assignment]
